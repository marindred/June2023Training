import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectiveDemoComponent } from './directive-demo.component';
import { FormsModule} from '@angular/forms';
import { NgModule } from '@angular/core';



describe('DirectiveDemoComponent', () => {
  let component: DirectiveDemoComponent;
  let fixture: ComponentFixture<DirectiveDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, NgModule],

      declarations: [DirectiveDemoComponent]
    });
    fixture = TestBed.createComponent(DirectiveDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
