import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-demo',
  templateUrl: './directive-demo.component.html',
  styleUrls: ['./directive-demo.component.css']
})
export class DirectiveDemoComponent {
  


  year : number=2023;

  isLeapYear : boolean=false;

  checkLeapYear(year: number)
  {
    this.year = year;
    this.isLeapYear=(this.year%4 === 0 && this.year %100 !==0) || (this.year === 0)
  }
}
